const express = require('express');
const userService = require('../services/userService');

const router = express.Router();

router.get('/', async ( req, res) =>{
    try{
        const users = await userService.getUsers();
        res.json(users);
    }
    catch(error){
        res.stauts(400).json({error: error.message});
    }
})

module.exports = router;