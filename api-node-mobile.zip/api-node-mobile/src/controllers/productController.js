const express = require('express');
const productService = require('../services/productService');
const authenticateToken = require('../middleware/auth');
const router = express.Router();

router.get('/',  async (req, res) =>{
    try{
        const users = await productService.getProduct();
        res.json(product);
    }
    catch(error){
        res.status(400).json({error: error.message});
    }
})

router.post('/', authenticateToken, async(req,res) =>{
    const {name, category, price, description } = req.body;
    const product = await productService.register(name, category, price, description );
    res.status(201).json(product);
})



module.exports = router;