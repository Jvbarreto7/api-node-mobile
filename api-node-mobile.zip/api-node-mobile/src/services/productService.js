const bcrypt = require('bcrypt');
const userRepository = require('../repositories/userRepository');
const { v4: UUIDV4 } = require('uuid');
const jwt = require('jsonwebtoken');
const productRepository = require('../repositories/productRepository');


class productService{
    async register(name, category, price, description){
        const getproduct = await this.getByName(name);
        console.log(getproduct);
        if(getproduct){
            throw new Error('Produto já cadastrado');
        }

        if (name.lenght <10 || name.lenght >60){
            throw new Error ('Nome do produto deve ter entre 10 e 60 caracteres');
        }

        if (category.lenght <10 || category.lenght >30){
            throw new Error ('Categoria deve ter entre 10 e 30 caracteres');
        }

        if (description.lenght <10 || description.lenght >500){
            throw new Error ('Descricao deve ter entre 10 e 500 caracteres');
        }
        const product = await productRepository.createproduct({id: UUIDV4(), name, category, price, description});
        return product;
    }

    async getByName(name){
        return await productRepository.findByName(name);
    }

    
    async getProduct(){
        return await productRepository.findAll();
    }
}

module.exports = new productService();