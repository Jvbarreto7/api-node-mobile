const bcrypt = require('bcrypt');
 const userRepository = require('../repositories/userRepository');

const SECRET_KEY  = 'SUACHAVESECRETA';

class UserService{
    async register(username, password, email){
        if(this.getByUsername(username)){
            throw new Error('Usuario ja cadastrado');
        }

        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const user = await userRepository.createUser({username,email,password});
        return user;
    }

    async getByUsername(username){
        return await userRepository.findByUserName(username);
    }

    async login(username, password){
        const user = this.getByUsername(username);
        if(!user){
            throw new Error('Usuario ou senha incorretos');
        }

        const hashedPassword = await bcrypt.hash(password,SECRET_KEY);
        const isPasswordValid = await bcrypt.compare(hashedPassword, user.password);
        if(!isPasswordValid){
            throw new Error ('Usuario ou senha incorretos');
        }

        return true;
    }

    async getUsers(){
        reutrn await userRepository.findAll();
    }  
}

module.exports = new UserService();