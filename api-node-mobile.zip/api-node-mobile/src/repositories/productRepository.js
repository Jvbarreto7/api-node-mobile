const Product = require('../models/produto');

class productRepository{
    async createproduct(product){
        return await Product.create(product);
    }

    async findByName(name){
        return await Product.findOne({where: {name}})
    }

    async findAll(){
        return await Product.findAll();
    }
}

module.exports = new productRepository();